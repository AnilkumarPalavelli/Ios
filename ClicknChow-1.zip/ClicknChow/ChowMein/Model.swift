//
//  Model.swift
//  ChowMein
//
//  Created by Chitrala,Bhanuteja on 4/23/23.
//

import Foundation

struct Menu {
    var itemName: String
    var itemPrice: Double
    var itemQuantity: Int
}

struct AppConstants {
    static let vegMenuItems: [Menu] = [
        Menu(itemName: "Gobi 65", itemPrice: 14.98, itemQuantity: 0),
        Menu(itemName: "Paneer Tikka", itemPrice: 19.98, itemQuantity: 0),
        Menu(itemName: "Mushroom Fry", itemPrice: 23.98, itemQuantity: 0),
        Menu(itemName: "Veg Biryani", itemPrice: 22.98, itemQuantity: 0),
        Menu(itemName: "Samabar Rice", itemPrice:18.98 , itemQuantity: 0),
        Menu(itemName: "Curd Rice", itemPrice:10.22 , itemQuantity: 0),
        Menu(itemName: "Paneer Fried Rice", itemPrice:17.98 , itemQuantity: 0),
        Menu(itemName: "Gobi Manchuria", itemPrice:17.98 , itemQuantity: 0),
        Menu(itemName: "Gulab Jamun", itemPrice:3.50 , itemQuantity: 0),
        Menu(itemName: "Kaju katli", itemPrice:3.98 , itemQuantity: 0)
    ]
    
    static let nonVegMenuItems: [Menu] = [
        Menu(itemName: "Hyderabadi Chicken Biryani", itemPrice: 14.98, itemQuantity: 0),
        Menu(itemName: "Haleem", itemPrice: 19.98, itemQuantity: 0),
        Menu(itemName: "Keema Biryani", itemPrice: 23.98, itemQuantity: 0),
        Menu(itemName: "Mutton Pulav", itemPrice: 22.98, itemQuantity: 0),
        Menu(itemName: "Shrimp Biryani", itemPrice:18.98 , itemQuantity: 0),
        Menu(itemName: "Chicken Kabab", itemPrice: 12.98, itemQuantity: 0),
        Menu(itemName: "Chicken Tandoori", itemPrice: 13.98, itemQuantity: 0),
        Menu(itemName: "Chicken Tikka", itemPrice: 15.98, itemQuantity: 0),
        Menu(itemName: "Shrimp Tandoori", itemPrice: 16.98, itemQuantity: 0),
        Menu(itemName: "Fish Fry", itemPrice: 13.98, itemQuantity: 0),
        Menu(itemName: "Fish Pulusu", itemPrice: 14.23, itemQuantity: 0)
    ]
}

let menuImages = ["Chicken-Kebabs","Gobi_65","chicken-tikka","Veg-Biryani","Tandoori-Chicken","Mushroom-65","Haleem","paneer_tikka","Hyderabadi-chicken-Biryani"]

struct Order {
    static var tableNumber: Int = 0
    static var orderItems: [Menu] = []
}

struct PaymentMethod {
    static let paymentOptions = ["Credit Card" , "Debit Card" , "Cash" , "Apple Pay"]
}
