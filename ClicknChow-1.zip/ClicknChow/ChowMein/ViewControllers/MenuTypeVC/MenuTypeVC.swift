//
//  MenuTypeVC.swift
//  ClickNChow
//
//  Created by Anumula,Anjith Kumar on 4/24/23.
//

import UIKit

class MenuTypeVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return menuImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = displayItemsCV.dequeueReusableCell(withReuseIdentifier: "itemImageCell", for: indexPath) as! MovieCollectionViewCell
        cell.assignFoodImage(with: menuImages[indexPath.row])
        
        return cell
    }
    

    
    
    @IBOutlet weak var displayItemsCV: UICollectionView!
    
    @IBOutlet weak var tableNumberLBL: UILabel!
    
    var tableNumber: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        displayItemsCV.delegate = self
        displayItemsCV.dataSource = self

        if tableNumber == "TakeOut" {
            tableNumberLBL.text = "TakeOut"
        } else {
            tableNumberLBL.text = "\(tableNumberLBL.text ?? "") \(tableNumber)"
        }
    }
    
    @IBAction func menuTypeSelected(_ sender: UIButton) {
        performSegue(withIdentifier: "menuTypeSegue", sender: sender.titleLabel?.text)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identiifier = segue.identifier else {return}
        
        if identiifier == "menuTypeSegue" {
            guard let destination = segue.destination as? MenuVC, let menuType = sender as? String else {return}
            destination.menuType = menuType
        }
    }
}
