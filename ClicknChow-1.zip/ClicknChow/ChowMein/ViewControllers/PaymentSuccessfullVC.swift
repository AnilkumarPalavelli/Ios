//
//  PaymentSuccessfullVC.swift
//  ChowMein
//
//  Created by Amrutha Varshini, Koduri on 4/23/23.
//

import UIKit


class PaymentSuccessfullVC: UIViewController {

    
    @IBOutlet weak var ImageOL: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ImageOL.image = UIImage(named: "paymentSuccessful")
        
        var w =  ImageOL.frame.width
               w += 40
               var h = ImageOL.frame.height
               h += 40
               
              var x =  ImageOL.frame.origin.x-20
               
               var y = ImageOL.frame.origin.y-20
               
               var largerFrame = CGRect(x: x, y: y, width: w, height: h)
               
               UIView.animate(withDuration: 3, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 100, animations: {
                   self.ImageOL.frame = largerFrame
               }) { _ in
                   Order.orderItems.removeAll()
                   self.navigationController?.popToRootViewController(animated: true)
               }
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
