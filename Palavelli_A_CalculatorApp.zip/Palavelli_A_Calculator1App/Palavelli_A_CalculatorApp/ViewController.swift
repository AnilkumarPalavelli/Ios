//
//  ViewController.swift
//  Palavelli_A_CalculatorApp
//
//  Created by Palavelli,Anil Kumar on 2/15/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var resultOutlet: UILabel!
    var Number1:String = " "
    var _operator:Character = " "
    var Number2:String = " "
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonACClicked(_ sender: UIButton) {
        resultOutlet.text = " "
        Number1 = " "
        Number2 = " "
        _operator = " "
    }
    
    @IBAction func buttonCClicked(_ sender: UIButton) {
        if(Number2 != " "){
            Number2 = String(Number2[Number2.startIndex..<Number2.index(Number2.endIndex,offsetBy: -1)])
            resultOutlet.text = Number2
        }
        else if(Number1 != " " ){
            Number1 = String(Number1[Number1.startIndex..<Number1.index(Number1.endIndex,offsetBy: -1)])
            resultOutlet.text = Number1
        }
    }
    
    @IBAction func buttonPlusOrMinusClicked(_ sender: UIButton) {
        if(Number2 != " "){
                            if(Number2.contains(".")){
                                Number2 = "\(-Double(Number2)!)"
                                resultOutlet.text=Number2
                            }
                            else{
                                Number2 = "\(-Int(Number2)!)"
                                resultOutlet.text=Number2
                            }
                            
                        }
                        else if(Number1 != " ") {
                            if(Number1.contains(".")){
                                Number1 = "\(-Double(Number1)!)"
                                resultOutlet.text=Number1
                            }
                            else{
                                Number1 = "\(-Int(Number1)!)"
                                resultOutlet.text=Number1
                            }
                        }
        
        
    }
    
    @IBAction func buttonDivisionClicked(_ sender: UIButton) {
        _operator = "÷"
    }
    @IBAction func button7Clicked(_ sender: UIButton) {
        if (Number1 == " " && _operator == " " ){
                           Number1="7"
                           resultOutlet.text="\(Number1)"
                       }else if(Number1 != " " && _operator == " " ){
                           Number1=Number1+"7"
                           resultOutlet.text="\(Number1)"
                       }
                       else if(Number2 == " " && _operator != " "){
                           Number2 = "7"
                           resultOutlet.text="\(Number2)"
                       }
                       else if(Number2 != " "){
                           Number2=Number2+"7"
                           resultOutlet.text="\(Number2)"
                   }
        
    }
    
    
    @IBAction func button8Clicked(_ sender: UIButton) {
        if (Number1 == " " && _operator == " " ){
                           Number1="8"
                           resultOutlet.text="\(Number1)"
                       }else if(Number1 != " " && _operator == " " ){
                           Number1=Number1+"8"
                           resultOutlet.text="\(Number1)"
                       }
                       else if(Number2 == " " && _operator != " "){
                           Number2 = "8"
                           resultOutlet.text="\(Number2)"
                       }
                       else if(Number2 != " "){
                           Number2=Number2+"8"
                           resultOutlet.text="\(Number2)"
                   }
    }
    
    @IBAction func button9Clicked(_ sender: UIButton) {
        if (Number1 == " " && _operator == " " ){
                           Number1="9"
                           resultOutlet.text="\(Number1)"
                       }else if(Number1 != " " && _operator == " " ){
                           Number1=Number1+"9"
                           resultOutlet.text="\(Number1)"
                       }
                       else if(Number2 == " " && _operator != " "){
                           Number2 = "9"
                           resultOutlet.text="\(Number2)"
                       }
                       else if(Number2 != " "){
                           Number2=Number2+"9"
                           resultOutlet.text="\(Number2)"
                   }
    }
    
    @IBAction func buttonMultiplyClicked(_ sender: UIButton) {
        _operator = "*"
    }
    
    @IBAction func button4Clicked(_ sender: UIButton) {
        if (Number1 == " " && _operator == " " ){
                           Number1="4"
                           resultOutlet.text="\(Number1)"
                       }else if(Number1 != " " && _operator == " " ){
                           Number1=Number1+"4"
                           resultOutlet.text="\(Number1)"
                       }
                       else if(Number2 == " " && _operator != " "){
                           Number2 = "4"
                           resultOutlet.text="\(Number2)"
                       }
                       else if(Number2 != " "){
                           Number2=Number2+"4"
                           resultOutlet.text="\(Number2)"
                   }
    }
    
    @IBAction func button5Clicked(_ sender: UIButton) {
        if (Number1 == " " && _operator == " " ){
                           Number1="5"
                           resultOutlet.text="\(Number1)"
                       }else if(Number1 != " " && _operator == " " ){
                           Number1=Number1+"5"
                           resultOutlet.text="\(Number1)"
                       }
                       else if(Number2 == " " && _operator != " "){
                           Number2 = "5"
                           resultOutlet.text="\(Number2)"
                       }
                       else if(Number2 != " "){
                           Number2=Number2+"5"
                           resultOutlet.text="\(Number2)"
                   }
    }
    
    @IBAction func button6Clicked(_ sender: UIButton) {
        if (Number1 == " " && _operator == " " ){
                           Number1="6"
                           resultOutlet.text="\(Number1)"
                       }else if(Number1 != " " && _operator == " " ){
                           Number1=Number1+"6"
                           resultOutlet.text="\(Number1)"
                       }
                       else if(Number2 == " " && _operator != " "){
                           Number2 = "6"
                           resultOutlet.text="\(Number2)"
                       }
                       else if(Number2 != " "){
                           Number2=Number2+"6"
                           resultOutlet.text="\(Number2)"
                   }
    }
    
    @IBAction func buttonSubtractClicked(_ sender: UIButton) {
        _operator = "-"
    }
    
    @IBAction func button1Clicked(_ sender: UIButton) {
        if (Number1 == " " && _operator == " " ){
                           Number1="1"
                           resultOutlet.text="\(Number1)"
                       }else if(Number1 != " " && _operator == " " ){
                           Number1=Number1+"1"
                           resultOutlet.text="\(Number1)"
                       }
                       else if(Number2 == " " && _operator != " "){
                           Number2 = "1"
                           resultOutlet.text="\(Number2)"
                       }
                       else if(Number2 != " "){
                           Number2=Number2+"1"
                           resultOutlet.text="\(Number2)"
                   }
    }
    
    @IBAction func button2Clicked(_ sender: UIButton) {
        if (Number1 == " " && _operator == " " ){
                           Number1="2"
                           resultOutlet.text="\(Number1)"
                       }else if(Number1 != " " && _operator == " " ){
                           Number1=Number1+"2"
                           resultOutlet.text="\(Number1)"
                       }
                       else if(Number2 == " " && _operator != " "){
                           Number2 = "2"
                           resultOutlet.text="\(Number2)"
                       }
                       else if(Number2 != " "){
                           Number2=Number2+"2"
                           resultOutlet.text="\(Number2)"
                   }
    }
    
    @IBAction func button3Clicked(_ sender: UIButton) {
        if (Number1 == " " && _operator == " " ){
                           Number1="3"
                           resultOutlet.text="\(Number1)"
                       }else if(Number1 != " " && _operator == " " ){
                           Number1=Number1+"3"
                           resultOutlet.text="\(Number1)"
                       }
                       else if(Number2 == " " && _operator != " "){
                           Number2 = "3"
                           resultOutlet.text="\(Number2)"
                       }
                       else if(Number2 != " "){
                           Number2=Number2+"3"
                           resultOutlet.text="\(Number2)"
                   }
    }
    
    @IBAction func buttonAddClicked(_ sender: UIButton) {
        _operator = "+"
    }
    
    @IBAction func button0Clicked(_ sender: UIButton) {
        if (Number1 == " " && _operator == " " ){
                           Number1="0"
                           resultOutlet.text="\(Number1)"
                       }else if(Number1 != " " && _operator == " " ){
                           Number1=Number1+"0"
                           resultOutlet.text="\(Number1)"
                       }
                       else if(Number2 == " " && _operator != " "){
                           Number2 = "0"
                           resultOutlet.text="\(Number2)"
                       }
                       else if(Number2 != " "){
                           Number2=Number2+"0"
                           resultOutlet.text="\(Number2)"
                   }
    }
    
    @IBAction func buttonDecimalClicked(_ sender: UIButton) {
        if (Number1 == " " && _operator == " " ){
                           Number1="."
                           resultOutlet.text="\(Number1)"
                       }else if(Number1 != " " && _operator == " " ){
                           Number1=Number1+"."
                           resultOutlet.text="\(Number1)"
                       }
                       else if(Number2 == " " && _operator != " "){
                           Number2 = "."
                           resultOutlet.text="\(Number2)"
                       }
                       else if(Number2 != " "){
                           Number2=Number2+"."
                           resultOutlet.text="\(Number2)"
                   }
    }
    
    @IBAction func buttonModClicked(_ sender: UIButton) {
        _operator = "%"
    }
    
    @IBAction func buttonEqualsClicked(_ sender: UIButton) {
        switch _operator{
                        case "+" :
                            if(Number1.contains(".")){
                                let OperaVal = "\(Double(Number1)! + Double(Number2)!)"
                                let firstindex = OperaVal.firstIndex(of: ".")!.utf16Offset(in: OperaVal)
                                let deciNumber = OperaVal[OperaVal.index(OperaVal.startIndex,offsetBy: firstindex+1)]
                                if(deciNumber != "0"){
                                    resultOutlet.text = OperaVal
                                }
                                else {
                                resultOutlet.text = "\(Int(Double(Number1)! + Double(Number2)!))"
                                }
                            }
                            else {
                                resultOutlet.text = "\(Int(Number1)! + Int(Number2)!)"
                            }
                            
                            
                        case "-" :
                         
                            if(Number1.contains(".")){
                                resultOutlet.text = "\(Double(Number1)! - Double(Number2)!)"
                            }
                            else {
                                resultOutlet.text = "\(Int(Number1)! - Int(Number2)!)"
                            }
                        
                        case "*" :
                            if(Number1.contains(".")){
                                resultOutlet.text = "\(Double(Number1)! * Double(Number2)!)"
                            }
                            else {
                                resultOutlet.text = "\(Int(Number1)! * Int(Number2)!)"
                            }
                            
                        case "÷" :
                            if(Number1.contains(".")){
                                resultOutlet.text = "\(Double(Number1)! / Double(Number2)!)"
                            }
                            else {
                                if(Number2 == "0"){
                                    resultOutlet.text = "Not a number"
                                }
                                else{
                                    let OperaVal = "\(Double(Number1)! / Double(Number2)!)"
                                    let firstindex = OperaVal.firstIndex(of: ".")!.utf16Offset(in: OperaVal)
                                    let deciNumber = OperaVal[OperaVal.index(OperaVal.startIndex,offsetBy: firstindex+1)]
                                    if(deciNumber != "0"){
                                        resultOutlet.text = "\(round(Double(OperaVal)!*100000)/100000)"
                                    }
                                    else{
                                        resultOutlet.text = "\(Double(Int(Number1)! / Int(Number2)!))"
                                    }
                                }
                                
                            }
                            
                        case "%" :
                            if(Number1.contains(".")){
                                let OperaVal1 = Double(Number1)!.truncatingRemainder(dividingBy: Double(Number2)!)
                                resultOutlet.text = "\(round(OperaVal1*10)/10)"
                            }
                            else {
                                resultOutlet.text = "\(Int(Number1)! % Int(Number2)!)"
                            }
                        
                            
                        default:
                            print("no operation")
                     
                        
                       }
    }
    

}

