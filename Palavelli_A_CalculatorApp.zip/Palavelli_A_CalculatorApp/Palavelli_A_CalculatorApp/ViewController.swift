//
//  ViewController.swift
//  Palavelli_A_CalculatorApp
//
//  Created by Palavelli,Anil Kumar on 2/15/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var resultOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonACClicked(_ sender: UIButton) {
    }
    
    @IBAction func buttonCClicked(_ sender: UIButton) {
    }
    
    @IBAction func buttonPlusOrMinusClicked(_ sender: UIButton) {
    }
    
    @IBAction func buttonDivisionClicked(_ sender: UIButton) {
    }
    @IBAction func button7Clicked(_ sender: UIButton) {
    }
    
    @IBAction func button8Clicked(_ sender: UIButton) {
    }
    
    @IBAction func button9Clicked(_ sender: UIButton) {
    }
    
    @IBAction func buttonMultiplyClicked(_ sender: UIButton) {
    }
    
    @IBAction func button4Clicked(_ sender: UIButton) {
    }
    
    @IBAction func button5Clicked(_ sender: UIButton) {
    }
    
    @IBAction func button6Clicked(_ sender: UIButton) {
    }
    
    @IBAction func buttonSubtractClicked(_ sender: UIButton) {
    }
    
    @IBAction func button1Clicked(_ sender: UIButton) {
    }
    
    @IBAction func button2Clicked(_ sender: UIButton) {
    }
    
    @IBAction func button3Clicked(_ sender: UIButton) {
    }
    
    @IBAction func buttonAddClicked(_ sender: UIButton) {
    }
    
    @IBAction func button0Clicked(_ sender: UIButton) {
    }
    
    @IBAction func buttonDecimalClicked(_ sender: UIButton) {
    }
    
    @IBAction func buttonModClicked(_ sender: UIButton) {
    }
    
    @IBAction func buttonEqualsClicked(_ sender: UIButton) {
    }
    

}

