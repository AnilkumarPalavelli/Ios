//
//  ViewController.swift
//  VowelTester
//
//  Created by Palavelli,Anil Kumar on 2/6/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textOutlet: UITextField!
    
    @IBOutlet weak var displayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonClicked(_ sender: UIButton) {
        // read the text
        var enteredtext = textOutlet.text!
        //check for a vowel
        if (enteredtext.contains("a") ||
            enteredtext.contains("e") || enteredtext.contains("i") || enteredtext.contains("i") || enteredtext.contains("o") || enteredtext.contains("u")){
            //display label
            displayLabel.text="The entered text contains vowel"
    
            }
        else{
            displayLabel.text="The entered text does not contain vowel"
        }
    
    }

}
