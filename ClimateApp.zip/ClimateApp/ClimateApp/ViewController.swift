//
//  ViewController.swift
//  ClimateApp
//
//  Created by Palavelli,Anil Kumar on 2/21/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var inputTempOutlet: UITextField!
    
    @IBOutlet weak var imageViewTemp: UIImageView!
    
    @IBOutlet weak var displayLbel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func clickmeToEvaluate(_ sender: UIButton) {
        var temp = Int(inputTempOutlet.text!)
        if(temp!<0){
            imageViewTemp.image = UIImage(named: "freezing")
            displayLbel.text = " It's too cold"
        }
        else if(temp!>=0 && temp!<=20){
            imageViewTemp.image = UIImage(named: "Sunny")
            displayLbel.text = " Its moderate temperature"
        }
        else{
            imageViewTemp.image = UIImage(named: "Hot")
            displayLbel.text = "It,s too hot"
        }
        
    }
    

}

