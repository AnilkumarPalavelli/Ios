//
//  ViewController.swift
//  Hello1
//
//  Created by Palavelli,Anil Kumar on 1/24/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameInput: UITextField!
    
    
    @IBOutlet weak var displaylabelOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonClick(_ sender: UIButton) {
        //Read the input and store it (assign it to a avriable.)
        
        var input = nameInput.text!
        
        //Perform String interpolation "Hello, name!" and assign to display label
           
        displaylabelOutlet.text = "Hello, \(input)!"
    }
    
}

