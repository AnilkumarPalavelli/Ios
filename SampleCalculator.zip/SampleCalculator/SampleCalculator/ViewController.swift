//
//  ViewController.swift
//  SampleCalculator
//
//  Created by Palavelli,Anil Kumar on 2/2/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displayLabel: UILabel!
    var operand1:Double = -1.1
    var _operator:Character = " "
    var operand2:Double = -1.1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func Button5Click(_ sender: UIButton) {
        //assign 5 to the display label
        displayLabel.text = displayLabel.text!+"5"
        if (operand1 == -1.1){
            operand1=5
    }
        else{
            operand2=5
        }
    }
    @IBAction func ButtonaddClick(_ sender: UIButton) {
        displayLabel.text="+"
        if(_operator == " "){
            _operator = "+"
        }
        
    }
    @IBAction func Button3Click(_ sender: UIButton) {
        displayLabel.text=displayLabel.text!+"3"
        if(operand2 == -1.1){
            operand2 = 3
        }
        else{
            operand1 = 3
        }
    }
    @IBAction func ButtonequalsClick(_ sender: UIButton) {
        displayLabel.text="="
        if(_operator == "+"){
            displayLabel.text = "\(operand1+operand2)"
        }
    }
    
    

}

