//
//  ViewController.swift
//  DisplayImageApp
//
//  Created by Palavelli,Anil Kumar on 2/21/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    @IBOutlet weak var descriptionLabelOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func displayImage(_ sender: Any) {
        //Display Image
        imageViewOL.image = UIImage(named:"Rohit Sharma")
        
        //Display the text in the label
        descriptionLabelOL.text = " Captain of the current Indian Cricket team in the all formats"
    }
    
}

