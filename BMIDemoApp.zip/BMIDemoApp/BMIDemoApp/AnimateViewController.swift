//
//  AnimateViewController.swift
//  BMIDemoApp
//
//  Created by Palavelli,Anil Kumar on 4/10/23.
//

import UIKit

class AnimateViewController: UIViewController {
    
    @IBOutlet weak var animateimageView: UIImageView!
     var imageName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        animateimageView.image = UIImage(named: imageName)
        
        var width = animateimageView.frame.width + 50
        var heigth = animateimageView.frame.height + 50
        
        var x = animateimageView.frame.origin.x-20
        var y = animateimageView.frame.origin.y-20
        var largeFrame = CGRect(x: x, y: y, width: width, height: heigth)
        UIView.animate(withDuration: 5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 50,  animations: {
            self.animateimageView.frame = largeFrame
        }  )
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
