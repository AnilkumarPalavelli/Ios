//
//  ViewController.swift
//  BMIDemoApp
//
//  Created by Palavelli,Anil Kumar on 4/10/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var heightOutlet: UITextField!
    
    @IBOutlet weak var weightOutlet: UITextField!
    
    @IBOutlet weak var calcBtnOutlet: UIButton!
    
    var bmi = 0.0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func calcbmiClicked(_ sender: UIButton) {
        
        var height = Double(heightOutlet.text!)
        var weight = Double(weightOutlet.text!)
        
        bmi = round(Double(weight!/(height!*height!))*100)/100
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "BMISegue"{
            var destination = segue.destination as! BMIViewController
            
            destination.bmivalue = bmi
    }
    

}

}
