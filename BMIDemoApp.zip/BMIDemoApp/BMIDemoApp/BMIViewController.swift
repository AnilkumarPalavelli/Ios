//
//  BMIViewController.swift
//  BMIDemoApp
//
//  Created by Palavelli,Anil Kumar on 4/10/23.
//

import UIKit

class BMIViewController: UIViewController {
    
    @IBOutlet weak var bmivalLabel: UILabel!
    
    
    @IBOutlet weak var imageviewOL: UIImageView!
    
    var bmivalue = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        bmivalLabel.text! = bmivalLabel.text!+"\(bmivalue)"
        imageviewOL.image = UIImage(named: "bmi")
    }
    
    
    @IBAction func animatebtnClicked(_ sender: UIButton) {
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "AnimateSegue"{
            //create destination
            var destination = segue.destination as! AnimateViewController
            
            destination.imageName = "bmi"
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
