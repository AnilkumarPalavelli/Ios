//
//  UniversityInfoViewController.swift
//  Palavelli_A_UniversityApp
//
//  Created by Palavelli,Anil Kumar on 4/19/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {
    
    var universityName = ""
    var universityImage = ""
    var universityInfo = ""
    
    @IBOutlet weak var universityImageViewOutlet: UIImageView!
    
    
    @IBOutlet weak var universityInfoOutlet: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.title = universityName
        universityImageViewOutlet.image = UIImage(named: universityImage)
        
        
        var height=universityImageViewOutlet.frame.height
                        var width=universityImageViewOutlet.frame.width
                        var x=universityImageViewOutlet.frame.origin.x-300
                        var y=universityImageViewOutlet.frame.origin.y
                        
                        var newFrame=CGRect(x: x, y: y, width: width, height: height)
                        
                        UIView.animate(withDuration: 0.8, delay: 0.2, usingSpringWithDamping: 1, initialSpringVelocity: 0, animations: {
                            self.universityImageViewOutlet.frame=newFrame
                        })
    }
    
    @IBAction func showInfoAction(_ sender: UIButton) {
        universityInfoOutlet.text = universityInfo
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
