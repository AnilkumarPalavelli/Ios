//
//  UniversityListViewController.swift
//  Palavelli_A_UniversityApp
//
//  Created by Palavelli,Anil Kumar on 4/19/23.
//

import UIKit

class UniversityListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return schools.list_Array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let myCell = universityListTableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath)
        //popolate a cell with data
        myCell.textLabel?.text = colleges[indexPath.row].collegeName
        //return a cell
        return myCell
    }
    
    
    var schools = Universities()
    var colleges : [UniversityList]=[]
    @IBOutlet weak var universityListTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.title = schools.domain
        colleges = schools.list_Array
        universityListTableView.delegate = self
        universityListTableView.dataSource = self
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "universityInfoSegue"{
            let destination = segue.destination as! UniversityInfoViewController
            
            //Send the Selected College row
            destination.universityName = colleges[(universityListTableView.indexPathForSelectedRow?.row)!].collegeName
            destination.universityImage = colleges[(universityListTableView.indexPathForSelectedRow?.row)!].collegeImage
            destination.universityInfo = colleges[(universityListTableView.indexPathForSelectedRow?.row)!].collegeInfo
        }
        
        
        /*
         // MARK: - Navigation
         
         // In a storyboard-based application, you will often want to do a little preparation before navigation
         override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         // Get the new view controller using segue.destination.
         // Pass the selected object to the new view controller.
         }
         */
        
    }
}
