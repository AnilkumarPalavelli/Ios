//
//  Universities.swift
//  Palavelli_A_UniversityApp
//
//  Created by Palavelli,Anil Kumar on 4/19/23.
//

import Foundation
import UIKit

struct UniversityList{
    var collegeName = " "
    var collegeImage = " "
    var collegeInfo = " "
}

struct Universities{
    var domain = " "
    var list_Array : [UniversityList] = []
}


let field1 = Universities(domain: "Information Technology", list_Array: [UniversityList(collegeName: "NWMSU", collegeImage: "northwest", collegeInfo: "Northwest has a history of bringing up educators, innovators and leaders since 1905. With 13 academic schools and departments and more than 150 major programs, students can follow their passion with the support they need to succeed. Students come to Northwest and find a home away from home."),
    UniversityList(collegeName: "University of Central Missouri", collegeImage: "ucm", collegeInfo: "University of Central Missouri is a public institution that was founded in 1871. It has a total undergraduate enrollment of 7,577 (fall 2021), its setting is rural, and the campus size is 1,561 acres. It utilizes a semester-based academic calendar."),
    UniversityList(collegeName: "Cleveland State University", collegeImage: "cleveland", collegeInfo: "Cleveland State University (CSU) is a public research university in Cleveland, Ohio. It was established in 1964 and opened for classes in 1965 after acquiring the entirety of Fenn College, a private school that had been in operation since 1923. CSU absorbed the Cleveland-Marshall College of Law (since renamed the Cleveland State University College of Law) in 1969. Today it is part of the University System of Ohio, has more than 120,000 alumni, and offers over 200 academic programs. It is classified among R2: Doctoral Universities – High research activity"),
    UniversityList(collegeName: "University of NorthTexas", collegeImage: "unt", collegeInfo: "The University of North Texas (UNT) is a public research university in Denton, Texas. It was founded as a nonsectarian, coeducational, private teachers college in 1890 and was formally adopted by the state 11 years later.UNT is a member of the University of North Texas System, which includes additional universities in Dallas and Fort Worth. UNT also has a location in Frisco."),
    UniversityList(collegeName: "Wright State University", collegeImage: "wright", collegeInfo: "Founded in 1956, USF is the fourth largest university in Florida by enrollment, with 49,766 students from over 145 countries, all 50 states, all five U.S. Territories, and the District of Columbia as of the 2022–2023 academic year.")])


let field2 = Universities(domain: "Computer Science", list_Array: [UniversityList(collegeName: "NWMSU", collegeImage: "northwest", collegeInfo: "Northwest has a history of bringing up educators, innovators and leaders since 1905. With 13 academic schools and departments and more than 150 major programs, students can follow their passion with the support they need to succeed. Students come to Northwest and find a home away from home."),
    UniversityList(collegeName: " University ofCentral Missouri", collegeImage: "unt", collegeInfo: "University of Central Missouri is a public institution that was founded in 1871. It has a total undergraduate enrollment of 7,577 (fall 2021), its setting is rural, and the campus size is 1,561 acres. It utilizes a semester-based academic calendar."),
    UniversityList(collegeName: "Cleveland State University", collegeImage: "cleveland", collegeInfo: "Cleveland State University (CSU) is a public research university in Cleveland, Ohio. It was established in 1964 and opened for classes in 1965 after acquiring the entirety of Fenn College, a private school that had been in operation since 1923. CSU absorbed the Cleveland-Marshall College of Law (since renamed the Cleveland State University College of Law) in 1969. Today it is part of the University System of Ohio, has more than 120,000 alumni, and offers over 200 academic programs. It is classified among R2: Doctoral Universities – High research activity."),
    UniversityList(collegeName: "University of North Texas", collegeImage: "unt", collegeInfo: "The University of North Texas (UNT) is a public research university in Denton, Texas. It was founded as a nonsectarian, coeducational, private teachers college in 1890 and was formally adopted by the state 11 years later.UNT is a member of the University of North Texas System, which includes additional universities in Dallas and Fort Worth. UNT also has a location in Frisco."),
    UniversityList(collegeName: "Wright State University", collegeImage: "wright", collegeInfo: "Founded in 1956, USF is the fourth largest university in Florida by enrollment, with 49,766 students from over 145 countries, all 50 states, all five U.S. Territories, and the District of Columbia as of the 2022–2023 academic year.")])




let field3 = Universities(domain: "Data Science and Analytics", list_Array: [UniversityList(collegeName: "UMBC", collegeImage: "umbc", collegeInfo: "The University of Maryland, Baltimore (UMB) is a public university in Baltimore, Maryland. Founded in 1807, it comprises some of the oldest professional schools of dentistry, law, medicine, pharmacy, social work and nursing in the United States.[3] It is the original campus of the University System of Maryland and has a strategic partnership with the University of Maryland, College Park."),
    UniversityList(collegeName: "University of Central Missouri", collegeImage: "ucm", collegeInfo: "University of Central Missouri is a public institution that was founded in 1871. It has a total undergraduate enrollment of 7,577 (fall 2021), its setting is rural, and the campus size is 1,561 acres. It utilizes a semester-based academic calendar."),
    UniversityList(collegeName: "University of North Texas", collegeImage: "unt", collegeInfo: "The University of North Texas (UNT) is a public research university in Denton, Texas. It was founded as a nonsectarian, coeducational, private teachers college in 1890 and was formally adopted by the state 11 years later.UNT is a member of the University of North Texas System, which includes additional universities in Dallas and Fort Worth. UNT also has a location in Frisco."),
    UniversityList(collegeName: "Wright State University", collegeImage: "wright", collegeInfo: "Founded in 1956, USF is the fourth largest university in Florida by enrollment, with 49,766 students from over 145 countries, all 50 states, all five U.S. Territories, and the District of Columbia as of the 2022–2023 academic year."),
    UniversityList(collegeName: "University of South Florida", collegeImage: "usf", collegeInfo: "Founded in 1956, USF is the fourth largest university in Florida by enrollment, with 49,766 students from over 145 countries, all 50 states, all five U.S. Territories, and the District of Columbia as of the 2022–2023 academic year.")])


let field4 = Universities(domain: "Cyber Security", list_Array: [UniversityList(collegeName: "University At Albany", collegeImage: "uab", collegeInfo: "The university enrolls 16,648 students in nine schools and colleges, which offer 50 undergraduate majors and 125 graduate degree programs.The university's academic choices include new and emerging fields in public policy, homeland security, globalization, documentary studies, biotechnology, and informatics."),
    UniversityList(collegeName: "Central Missouri", collegeImage: "ucm", collegeInfo: "University of Central Missouri is a public institution that was founded in 1871. It has a total undergraduate enrollment of 7,577 (fall 2021), its setting is rural, and the campus size is 1,561 acres. It utilizes a semester-based academic calendar."),
    UniversityList(collegeName: "George Mason University", collegeImage: "gmu", collegeInfo: "George Mason University (George Mason, Mason, or GMU) is a public research university in Fairfax County, Virginia, with an independent City of Fairfax postal address in the Washington metropolitan area. The university was originally founded in 1949 as a Northern Virginia regional branch of the University of Virginia."),
    UniversityList(collegeName: "University of North Texas", collegeImage: "unt", collegeInfo: "The University of North Texas (UNT) is a public research university in Denton, Texas. It was founded as a nonsectarian, coeducational, private teachers college in 1890 and was formally adopted by the state 11 years later.UNT is a member of the University of North Texas System, which includes additional universities in Dallas and Fort Worth. UNT also has a location in Frisco."),
    UniversityList(collegeName: "Wright State University", collegeImage: "wright", collegeInfo: "Founded in 1956, USF is the fourth largest university in Florida by enrollment, with 49,766 students from over 145 countries, all 50 states, all five U.S. Territories, and the District of Columbia as of the 2022–2023 academic year.")])




let colleges :[Universities] = [field1,field2,field3,field4]


