//
//  ViewController.swift
//  Palavelli_A_UniversityApp
//
//  Created by Palavelli,Anil Kumar on 4/19/23.
//

import UIKit

class UniversitiesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var fields = colleges
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fields.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let myCell = UniversitiesTableview.dequeueReusableCell(withIdentifier: "domainCell", for: indexPath)
        //popolate a cell with data
        myCell.textLabel?.text = fields[indexPath.row].domain
        //return a cell
        return myCell
    }
    
    
    
    @IBOutlet weak var UniversitiesTableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UniversitiesTableview.delegate = self
        UniversitiesTableview.dataSource = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "listsSegue"{
            let destination = segue.destination as! UniversityListViewController
            
            //Send the Selected College row
            destination.schools = fields[(UniversitiesTableview.indexPathForSelectedRow?.row)!]
        }
        
        
    }
    
}
