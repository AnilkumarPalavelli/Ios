//
//  ViewController.swift
//  samplePracticeApp
//
//  Created by Palavelli,Anil Kumar on 1/26/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var crs1Outlet: UITextField!
    
    @IBOutlet weak var crs2Outlet: UITextField!
    
    @IBOutlet weak var displayLabelOutlet: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func buttonClicked(_ sender: UIButton) {
        //read the course 1 name and store it in a variable
        var course1name = crs1Outlet.text!;
        // Read the course 2 name and store it in a variable.
        var course2Name = crs2Outlet.text!;
        
        //Perform string interpolation and assign it to display label.(course1 -course2)
        
        displayLabelOutlet.text="\(course1name)-\(course2Name)"
        
    }
    

}

