//
//  ResultViewController.swift
//  PercentageAppWithMultipleControllers
//
//  Created by Palavelli,Anil Kumar on 4/3/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var EnteredMarksOutlet: UILabel!
    
    
    @IBOutlet weak var MarksTotalOutlet: UILabel!
    
    @IBOutlet weak var PercentageOutlet: UILabel!
    
    var marksScored = ""
    var totalmarks1 = ""
    var percentageaftercalc = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        EnteredMarksOutlet.text = EnteredMarksOutlet.text!+marksScored
        MarksTotalOutlet.text = MarksTotalOutlet.text!+totalmarks1
        
        PercentageOutlet.text=PercentageOutlet.text!+percentageaftercalc
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
