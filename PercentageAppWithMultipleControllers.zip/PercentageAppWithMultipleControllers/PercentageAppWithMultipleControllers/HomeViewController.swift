//
//  ViewController.swift
//  PercentageAppWithMultipleControllers
//
//  Created by Palavelli,Anil Kumar on 4/3/23.
//

import UIKit

class HomeViewController: UIViewController {
    
    @IBOutlet weak var MarksObtainedOutlet: UITextField!
    
    
    @IBOutlet weak var TotalMarksOutlet: UITextField!
    var percentage = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func CalculatePercentageButtonClicked(_ sender: UIButton) {
        var marks = MarksObtainedOutlet.text!
        print(marks)
        
        var totalmarks = TotalMarksOutlet.text!
        print(totalmarks)
        
        percentage = (Double(marks)! / Double(totalmarks)!)*100
        
        percentage = round(percentage*100)/100.0
        
        print(percentage)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition = segue.identifier
        if transition == "ResultSegue"{
            //Create Destination
            var destination = segue.destination as! ResultViewController
            
            destination.marksScored = MarksObtainedOutlet.text!
            destination.totalmarks1 = TotalMarksOutlet.text!
            destination.percentageaftercalc = String(percentage)
        }
    }
    

}

