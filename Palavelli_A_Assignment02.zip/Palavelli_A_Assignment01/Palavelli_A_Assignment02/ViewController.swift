//
//  ViewController.swift
//  Palavelli_A_Assignment02
//
//  Created by Palavelli,Anil Kumar on 1/31/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstNameOutlet: UITextField!
    
    @IBOutlet weak var lastNameOutlet: UITextField!
    
    @IBOutlet weak var yearOutlet: UITextField!
    
    @IBOutlet weak var DetailsLabel: UILabel!
    @IBOutlet weak var fullNameLabel: UILabel!
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    @IBOutlet weak var ageLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func SubmitBTN(_ sender: UIButton) {
        var firstName=firstNameOutlet.text!
        var lastName=lastNameOutlet.text!
        var birthyear=yearOutlet.text!
        DetailsLabel.text="Details"
        fullNameLabel.text="Full Name : \(lastName) \(firstName)"
        initialsLabel.text="initials : \(lastName[lastName.startIndex]) \(firstName[firstName.startIndex])"
        ageLabel.text="Age : \(2023 - Int(birthyear)!)"
        
        
    }
    
    @IBAction func ResetBTN(_ sender: UIButton) {
        firstNameOutlet.text=" "
        lastNameOutlet.text=" "
        yearOutlet.text=" "
        DetailsLabel.text=" "
        fullNameLabel.text=" "
        initialsLabel.text=" "
        ageLabel.text=" "
        
    
    }
    

}

