//
//  ViewController.swift
//  Palavelli_A_SearchApp
//
//  Created by Palavelli,Anil Kumar on 3/19/23.
//

import UIKit

class ViewController: UIViewController {
    var heroines=[["h1","Anushka made her acting debut in 2005 with the Telugu film Super and later appeared in several successful Telugu and Tamil films, including Arundhati,Vedam,Baahubali: The Beginning, Baahubali: The Conclusion, Singam, Deiva Thirumagal, Irandaam Ulagam, and Rudhramadevi"],
                    ["h2","Anupama made her acting debut in 2015 with the Malayalam film Premam and later made her Telugu debut in 2016 with the film A Aa. She has since appeared in several successful films, including Shatamanam Bhavati, Vunnadhi Okate Zindagi, Krishnarjuna Yudham, Tej I Love You, Rakshasudu, and Unnimoolam"],
                    ["h3","Kajal Aggarwal (born 19 June 1985) is an Indian actress and model who mainly appears in Telugu and Tamil language films, in addition to a few Hindi films.Aggarwal has worked in more than 50 films and also received two South Indian International Movie Awards."],
                    ["h4","Samantha made her acting debut in 2010 with the Telugu film Ye Maaya Chesave and later appeared in several successful Telugu and Tamil films, including Dookudu, Eega, Manam, Theri, 24, Mersal, and Oh Baby.Samantha has won several awards for her performances, including four Filmfare Awards, three Nandi Awards, and the Tamil Nadu State Film Award."],
                    ["h5","Keerthy Suresh (born 17 October 1992) is an Indian actress, dancer, playback singer, philanthropist and promotional model who appears predominantly in Tamil and Telugu films, in addition to a few Malayalam films. She won the National Film Award for Best Actress for portraying actress Savitri in the Telugu film Mahanati (2018). She has also received three SIIMA Awards, one Filmfare Award South "]]
        
        var singers=[["s1","SP Balasubrahmanyam, also known as SPB, was a legendary Indian playback singer, music director, actor, dubbing artist, and film producer who primarily worked in the Tamil, Telugu, Kannada, Hindi, and Malayalam film industries. He was born on June 4, 1946, in Nellore, Andhra Pradesh, India, and passed away on September 25, 2020."],
                     ["s2","Nagoor Babu, known by his stage name Mano, is an Indian playback singer, voice-over artist, actor, producer, television anchor and composer. [1] Mano has recorded more than 24,000 songs for film and private various Telugu, Tamil, Kannada, Malayalam, Hindi, Tulu, Konkani and Assamese films."],
                     ["s3","Krishnan Nair Shantakumari Chithra (born 27 July 1963), always credited as K. S. Chithra or Chithra, is an Indian playback singer and Carnatic musician. In a career spanning over four decades, she has recorded over 25,000 songs in various Indian languages,as well as foreign languages such as Malay, Latin, Arabic, Sinhalese, English and French"],
                     ["s4","Geetha Madhuri made her singing debut in 2005 with the Telugu film Tapana and has since sung for numerous successful films, including Pournami, Chirutha, Aarya 2, Magadheera, Baahubali: The Beginning, Baahubali: The Conclusion, Krishnarjuna Yuddham, and Aravinda Sametha Veera Raghava"],
                     ["s5","Shreya Ghoshal is a popular Indian playback singer who is known for her chartbuster songs. She has lent her voice in various languages and has worked with almost every top music directors in India. Shreya Ghoshal was born on 12 March 1984 (age 36 years; as in 2020) in the Berhampore city of Murshidabad district, West Bengal. "]]
       
        var comedians=[["c1","Kanneganti Brahmanandam(born 1 February 1956), known mononymously as Brahmanandam,is an Indian actor, comedian, impersonator, and voice actor known for his works predominantly in Telugu cinema.He holds the Guinness World Record for the most screen credits for a living actor, appearing in over 1000 films to date.He was awarded an honorary doctorate by Acharya Nagarjuna University.In 2009,he was honoured with the Padma Shri,the fourth-highest civilian award in India"],
                    ["c2","M.S. Narayana made his acting debut in 1997 with the Telugu film Rajendrudu Gajendrudu and went on to appear in over 700 films throughout his career. He was known for his excellent comic timing and natural acting skills and was a popular figure among Telugu film audiences."],
                    ["c3","Indukuri Sunil Varma (born 28 February 1974), known mononymously as Sunil, is an Indian actor who works in Telugu films. Noted for his comic roles, Sunil has appeared in over 180 films in his career, including around 1IFC0 films in lead role. He has won three state Nandi Awards and two Filmfare Awards South."],
                    ["c4","Ali made his acting debut in 1988 with the Telugu film Mukku Pudaka and has since appeared in over 1000 films in Telugu, Tamil, and Hindi languages. He is known for his excellent comic timing and has won several awards for his performances, including the Nandi Award for Best Male Comedian for Yuvakudu and Bhale Bhale Magadivoy"],
                       ["c5","Venu Madhav was a popular Indian actor and comedian who primarily worked in the Telugu film industry. He was born on December 30, 1979, in Kodad, Telangana, India, and passed away on September 25, 2019.Venu Madhav made his acting debut in 1996 with the Telugu film ,Sampradayam, and went on to appear in over 600 films throughout his career."]]
    
    var heroines_keywords = ["Actress","actresses","heroiens","leading ladies","celebrities"]
    var singers_keywords = ["musicians","Singers","singers","play back singers","vocalists"]
    var comedians_keywords = ["comics","Comedians","comedians","entertainers","humaorists","jokers"]
    
    var topic = -1;
    var index=0
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var searchOutlet: UIButton!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var previousBtnOutlet: UIButton!
    
    @IBOutlet weak var resetBtnOutlet: UIButton!
    
    @IBOutlet weak var nextBtnOutlet: UIButton!
    
    @IBAction func textEntered(_ sender: UITextField) {
        searchOutlet.isEnabled=true
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        hideButtons()
        resultImage.image=UIImage(named: "welcome1")
        searchOutlet.isEnabled=false
    }
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        previousBtnOutlet.isHidden=false
        resetBtnOutlet.isHidden=false
        nextBtnOutlet.isHidden=false
        index = 0
        if(heroines_keywords.contains(searchTextField.text!)){
            topic=1
        }
        else if(singers_keywords.contains(searchTextField.text!)){
            topic=2
        }
        else if(comedians_keywords.contains(searchTextField.text!)){
            topic=3
        }
        else{
            topic=0
        }
        if(topic==0){
            resultImage.image=UIImage(named: "noresults")
            hideButtons()
            topicInfoText.text=""
        }
        else if(topic==1){
            resultImage.image=UIImage(named: heroines[index][0])
            topicInfoText.text=heroines[index][1]
            enableButtons()
            previousBtnOutlet.isEnabled=false
            nextBtnOutlet.isEnabled=true
        }
        else if(topic==2){
            resultImage.image=UIImage(named: singers[index][0])
            topicInfoText.text=singers[index][1]
            enableButtons()
            previousBtnOutlet.isEnabled=false
            nextBtnOutlet.isEnabled=true
        }
        else if(topic==3){
            resultImage.image=UIImage(named: comedians[index][0])
            topicInfoText.text=comedians[index][1]
            enableButtons()
            previousBtnOutlet.isEnabled=false
            nextBtnOutlet.isEnabled=true
       }
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
        index=index-1
        updateDetails(_index: index)
        nextBtnOutlet.isEnabled=true
        if(index==0||index==0||index==0){
            previousBtnOutlet.isEnabled=false
            
        }
        
        
    }
    
    @IBAction func ResetBtn(_ sender: UIButton) {
        searchTextField.text=""
        topicInfoText.text=""
        hideButtons()
        searchOutlet.isEnabled=false
        resultImage.image=UIImage(named: "welcome1")
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
        index=index+1
        updateDetails(_index: index)
        previousBtnOutlet.isEnabled=true
        if(index==heroines.count-1||index==singers.count-1||index==comedians.count-1){
            nextBtnOutlet.isEnabled=false
        }
    }
    func updateDetails(_index:Int){
        if(topic==1){
            resultImage.image=UIImage(named: heroines[index][0])
            topicInfoText.text=heroines[index][1]
        }
        else if(topic==2){
            resultImage.image=UIImage(named: singers[index][0])
            topicInfoText.text=singers[index][1]
            
        }
        else if(topic==3){
            resultImage.image=UIImage(named: comedians[index][0])
            topicInfoText.text=comedians[index][1]
        }
    }
    
    func hideButtons(){
        previousBtnOutlet.isHidden=true
        resetBtnOutlet.isHidden=true
        nextBtnOutlet.isHidden=true
    }
    func enableButtons(){
        previousBtnOutlet.isEnabled=true
        resetBtnOutlet.isEnabled=true
        nextBtnOutlet.isEnabled=true
    }
    

}

