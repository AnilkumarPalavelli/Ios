//
//  ResultViewController.swift
//  DiscountAppMVController
//
//  Created by Palavelli,Anil Kumar on 3/30/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var displayamountOutlet: UILabel!
    
    
    @IBOutlet weak var displayDiscountOutlet: UILabel!
    
    @IBOutlet weak var resultOutlet: UILabel!
    
    var amount = ""
    var discrate = ""
    var priceAfterDisc = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        displayamountOutlet.text! += amount
        displayDiscountOutlet.text! += discrate
        resultOutlet.text! += priceAfterDisc
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
