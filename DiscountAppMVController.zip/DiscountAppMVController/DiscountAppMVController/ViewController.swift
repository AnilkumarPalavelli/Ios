//
//  ViewController.swift
//  DiscountAppMVController
//
//  Created by Palavelli,Anil Kumar on 3/30/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var amountOutlet: UITextField!
    
    
    @IBOutlet weak var discountOutlet: UITextField!
    
    var priceAfterDisc = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func calPriceButtonClicked(_ sender: UIButton) {
        //Read the text and converterd to double
        var amount = Double(amountOutlet.text!)
        print(amount!)
        var discrate = Double(discountOutlet.text!)
        print(discrate!)
        
        priceAfterDisc = amount! - (amount!*discrate!/100)
        print(priceAfterDisc)
        
       
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if(transition == "resultSegue"){
            //set the destination
            var destination = segue.destination
            as! ResultViewController
            
            //Assign appropriate values to the destination
            destination.amount = amountOutlet.text!
            destination.discrate = discountOutlet.text!
            destination.priceAfterDisc = String(priceAfterDisc)
        }
    }
    

}

