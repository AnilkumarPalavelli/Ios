//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Palavelli,Anil Kumar on 3/16/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    
  
    @IBOutlet weak var crsNum: UILabel!
    
    @IBOutlet weak var crsTitle: UILabel!
    
    
    @IBOutlet weak var semOutlet: UILabel!
    
    @IBOutlet weak var nextBtn: UIButton!
    
    @IBOutlet weak var previousBtn: UIButton!
    
    let courses = [["img01","44555","Network Security","Fall 2022"],["img02","44643","iOS","Spring 2023"],["img03","44656","Streaming Data","Fall 2024"]]
    
    var imageNumber = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //Load the first image (in the 0th position)
        updateCourseDetails(imageNumber: imageNumber)
        
        //Previous button disabled
        previousBtn.isEnabled = false
        
        //next button enabled
        
        nextBtn.isEnabled = true
    }
    

    @IBAction func buttonPtrvious(_ sender: UIButton) {
        //Decrement the imageNumber
        imageNumber -= 1
        
        //Update the course details
        
        updateCourseDetails(imageNumber: imageNumber)
        
        //next button should be enabled
        
        nextBtn.isEnabled = true
        
        //once you reach the starting of the array,we need to disable the previous button
        
        if(imageNumber==0){
            previousBtn.isEnabled = false
        }
    }
    
    
    
    @IBAction func buttonNext(_ sender: UIButton) {
        
        //incement imagenumber
         
        imageNumber += 1
        
        //Update the course details of the next course(image,num,,title,and sem offered)
        
        updateCourseDetails(imageNumber: imageNumber)
        
        //previous button should be enabled
        previousBtn.isEnabled = true
        
        //when we reach the end of the array , next button should be disabled
        
        if(imageNumber==courses.count-1){
            //reached the end of the array
            nextBtn.isEnabled = false
        }
        

    }
    func updateCourseDetails(imageNumber:Int){
        imageView.image = UIImage(named: courses[imageNumber][0])
        crsNum.text = courses[imageNumber][1]
        crsTitle.text = courses[imageNumber][2]
        semOutlet.text = courses[imageNumber][3]
        
}


}
